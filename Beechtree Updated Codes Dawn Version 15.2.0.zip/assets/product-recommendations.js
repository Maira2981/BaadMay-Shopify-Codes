class ProductRecommendations extends HTMLElement {
  observer = undefined;

  constructor() {
    super();
  }

  connectedCallback() {
    this.initializeRecommendations(this.dataset.productId);
  }

  initializeRecommendations(productId) {
    this.observer?.unobserve(this);
    this.observer = new IntersectionObserver(
      (entries, observer) => {
        if (!entries[0].isIntersecting) return;
        observer.unobserve(this);
        this.loadRecommendations(productId);
      },
      { rootMargin: '0px 0px 400px 0px' }
    );
    this.observer.observe(this);
  }

  loadRecommendations(productId) {
    fetch(`${this.dataset.url}&product_id=${productId}&section_id=${this.dataset.sectionId}`)
      .then((response) => response.text())
      .then((text) => {
        const html = document.createElement('div');
        html.innerHTML = text;
        const recommendations = html.querySelector('product-recommendations');

        if (recommendations?.innerHTML.trim().length) {
          this.innerHTML = recommendations.innerHTML;
        }

        if (!this.querySelector('slideshow-component') && this.classList.contains('complementary-products')) {
          this.remove();
        }

        if (html.querySelector('.cstm-grid__item')) {
          this.classList.add('product-recommendations--loaded');
        }

        var recommend_swiper = new Swiper("product-recommendations .recommend_swiper", {
          slidesPerView: 'auto',
          loop:true,
          speed: 800,
          breakpoints: {
            750: {
              slidesPerView: 'auto',
            }
          },
          navigation: {
            nextEl: "product-recommendations .swiper-button-next",
            prevEl: "product-recommendations .swiper-button-prev",
          }
        });

        let gridWrapper = document.querySelector('.recommend_swiper');

        const cardAtcBtn = () => {
          gridWrapper.querySelectorAll('.card-wrapper-box').forEach( (quickCartContainer) => {
            quickCartContainer.querySelector('.bt-qatc-btn-container').addEventListener('click', (evt) => {
              quickCartContainer.querySelector('.bt-qatc-container').addEventListener('click', (evt) => {
                if (evt.target.classList.contains('bt-qatc-container')) {
                  quickCartContainer.querySelector('.bt-qatc-container').classList.remove('is-visible');
                  quickCartContainer.querySelector('.bt-qatc-form-container').classList.remove ('is-visible');
                  if (window.innerWidth < 769) {
                    document.querySelector('product-recommendations .recommend_swiper ul').classList.remove('active');
                    document.querySelector('product-recommendations .swiper-slide').classList.remove('active');
                  }
                }
              });
              quickCartContainer.querySelector('.bt-qatc-container').classList.add('is-visible');
              quickCartContainer.querySelector('.bt-qatc-form-container').classList.add('is-visible');
              if (window.innerWidth < 769) {
                document.querySelector('product-recommendations .recommend_swiper ul').classList.add('active');
                document.querySelector('product-recommendations .swiper-slide').classList.add('active');
              }
              const atcForm = quickCartContainer.querySelector('.bt-qatc-form');
              atcForm.addEventListener('input', (e) => {
                e.preventDefault();
                atcFormApi(atcForm);
                atcForm.reset();
                quickCartContainer.querySelector('.bt-qatc-container').classList.remove('is-visible');
                quickCartContainer.querySelector('.bt-qatc-form-container').classList.remove('is-visible');
                if (window.innerWidth < 769) {
                  document.querySelector('product-recommendations .recommend_swiper ul').classList.add('active');
                  document.querySelector('product-recommendations .swiper-slide').classList.add('active');
                }
              });
            });
          });
        };

        async function atcFormApi(form) {
          try {
            const cartSections = document.querySelector('cart-notification, cart-drawer');
            const formData = new FormData(form);
            if (cartSections) {
              formData.append('sections', Array.from(cartSections.getSectionsToRender(), section => section.id));
            }

            formData.append('sections_url', window.location.pathname)
            const resp = await fetch('/cart/add.js', {
              method: 'POST',
              body: formData
            });

            if (!resp.ok) {
              throw new Error("Error While adding to cart")
            }

            const data = await resp.json();

            if (cartSections) {
              cartSections.renderContents(data);
            }
          } catch (error) {
            console.log("Quick add to cart error!!!", error)
          }
        };

        const variantListClose = () => {
          if (window.innerWidth > 768) {
          gridWrapper.querySelectorAll('.cstm-grid__item').forEach( productCard => {
            productCard.addEventListener('mouseleave', () => {
              if (productCard.querySelector('.bt-qatc-form-container')) {
                productCard.querySelector('.bt-qatc-form-container').classList.remove('is-visible');
              }
            });
          });
        }
        }

        const cardSlider = () => {
          let gridItems = gridWrapper.querySelectorAll('.cstm-grid__item');
          gridItems.forEach( item => {
            var swiper = new Swiper(item.querySelector('.card_carousel'), {
              loop: true,
              mousewheel: true,
              pagination: {
                el: ".swiper-pagination",
                clickable: true,
              }
            });
          });
        }

        const productSizechart = (sizeChartContainer) => {
          if (sizeChartContainer.querySelector('#cm2') && sizeChartContainer.querySelector('#inches2') && sizeChartContainer.querySelector('table')) {

            function inchesToCentimeters(inches) {
              return inches * 2.54;
            }

            function centimetersToInches(cm) {
              return cm / 2.54;
            }

            function toggleUnit(unit) {
              let sizeCells = sizeChartContainer.querySelectorAll('td:not(.sc__item)');
              sizeCells.forEach(function(cell) {
                let originalValue = parseFloat(cell.getAttribute('data-original-value'));
                if (!isNaN(originalValue)) {
                  if (unit === 'cm') {
                    let cm = inchesToCentimeters(originalValue);
                    cell.textContent = cm.toFixed(2);
                  } else if (unit === 'inches') {
                    let inches = originalValue;
                    cell.textContent = inches.toFixed(2);
                  }
                } else {
                  cell.textContent = '-';
                }
              });

              if (unit === 'inches') {
                sizeChartContainer.querySelector('#inches2').classList.add('active');
                sizeChartContainer.querySelector('#cm2').classList.remove('active');
              } else if (unit === 'cm') {
                sizeChartContainer.querySelector('#cm2').classList.add('active');
                sizeChartContainer.querySelector('#inches2').classList.remove('active');
              }
            }

            function storeOriginalValues() {
              let sizeCells = sizeChartContainer.querySelectorAll('table td');
              sizeCells.forEach(function(cell) {
                let value = parseFloat(cell.textContent);
                if (!isNaN(value)) {
                  cell.setAttribute('data-original-value', value);
                } else {
                  cell.setAttribute('data-original-value', '-');
                }
              });
            }

            storeOriginalValues();

            let selectedUnit = 'inches';
            toggleUnit(selectedUnit);

            sizeChartContainer.querySelector('#cm2').addEventListener('click', function() {
              selectedUnit = 'cm';
              toggleUnit(selectedUnit);
            });

            sizeChartContainer.querySelector('#inches2').addEventListener('click', function() {
              selectedUnit = 'inches';
              toggleUnit(selectedUnit);
            });
          }
        }

        const sizeChartCloseBtn = (sizeChartContainer) => {
          sizeChartContainer.querySelector('.bt-sc-close-btn,.bt-sc-overlay').addEventListener('click', () => {
            document.querySelector('.bt-sc-overlay').removeAttribute('style');
            sizeChartContainer.removeAttribute('style');
            sizeChartContainer.querySelector('.bt-sc-items-container').innerHTML = null;
            sizeChartContainer.querySelector('img').src = '';
          });

          document.querySelector('.bt-sc-overlay').addEventListener('click', () => {
            document.querySelector('.bt-sc-overlay').removeAttribute('style');
            sizeChartContainer.removeAttribute('style');
            sizeChartContainer.querySelector('.bt-sc-items-container').innerHTML = null;
            sizeChartContainer.querySelector('img').src = '';
            document.querySelector('.bt-card-variant-list-wrapper').classList.remove('active');
          });
        };

        const sizeChartBtn = () => {
          document.querySelectorAll('.bt-qatc-measurement-input').forEach( scBtn => {
            scBtn.addEventListener('click', (evt) => {
              document.querySelector('#bt-sc-overlay').style.display = 'block';
              const sizeChartContainer = document.querySelector('#bt-sc-container');
              sizeChartContainer.style.transform = 'translateX(0px)';
              sizeChartContainer.querySelector('.bt-sc-title h2').innerText = evt.target.dataset.scTitle;
              sizeChartContainer.querySelector('.bt-sc-media img').src = evt.target.dataset.scImg;
              let cloneSc = evt.target.nextElementSibling.cloneNode(true);
              sizeChartContainer.querySelector('.bt-sc-items-container').append(cloneSc)
              sizeChartContainer.querySelector('.bt-sc-items-container .bt-qatc-collection-chart').style.display = 'block';

              sizeChartCloseBtn(sizeChartContainer);
              productSizechart(sizeChartContainer);
            });
          });
        };

        cardSlider();
        cardAtcBtn();
        variantListClose();
        sizeChartBtn();

      })
      .catch((e) => {
        console.error(e);
      });
  }
}

customElements.define('product-recommendations', ProductRecommendations);
