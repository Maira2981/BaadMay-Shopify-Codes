
  let gridWrapper = document.querySelector('#product-grid');

  const cardAtcBtn = () => {

    gridWrapper.querySelectorAll('.card-wrapper-box').forEach( (quickCartContainer) => {
      quickCartContainer.querySelector('.bt-qatc-btn-container').addEventListener('click', (evt) => {
        quickCartContainer.querySelector('.bt-qatc-container').addEventListener('click', (evt) => {
          if (evt.target.classList.contains('bt-qatc-container')) {
            quickCartContainer.querySelector('.bt-qatc-container').classList.remove('is-visible');
            quickCartContainer.querySelector('.bt-qatc-form-container').classList.remove ('is-visible');
          }
        });
        quickCartContainer.querySelector('.bt-qatc-container').classList.add('is-visible');
        quickCartContainer.querySelector('.bt-qatc-form-container').classList.add('is-visible');
        const atcForm = quickCartContainer.querySelector('.bt-qatc-form');
        atcForm.addEventListener('input', (e) => {
          e.preventDefault();
          atcFormApi(atcForm);
          atcForm.reset();
          quickCartContainer.querySelector('.bt-qatc-container').classList.remove('is-visible');
          quickCartContainer.querySelector('.bt-qatc-form-container').classList.remove('is-visible');
        });
      });
    });
  }

  async function atcFormApi(form) {
    try {
      const cartSections = document.querySelector('cart-notification, cart-drawer');
      const formData = new FormData(form);
      if (cartSections) {
        formData.append('sections', Array.from(cartSections.getSectionsToRender(), section => section.id));
      }

      formData.append('sections_url', window.location.pathname)
      const resp = await fetch('/cart/add.js', {
        method: 'POST',
        body: formData
      });

      if (!resp.ok) {
        throw new Error("Error While adding to cart")
      }

      const data = await resp.json();

      if (cartSections) {
        cartSections.renderContents(data);
      }
    } catch (error) {
      console.log("Quick add to cart error!!!", error)
    }
  }

  const variantListClose = () => {
    if (window.innerWidth > 768) {
    gridWrapper.querySelectorAll('.grid__item').forEach( productCard => {
      productCard.addEventListener('mouseleave', () => {
        if (productCard.querySelector('.bt-qatc-form-container')) {
          productCard.querySelector('.bt-qatc-form-container').classList.remove('is-visible');
        }
      });
    });
  }
  }

  const cardSlider = () => {
    let gridItems = gridWrapper.querySelectorAll('.grid__item');
    gridItems.forEach( item => {
      var swiper = new Swiper(item.querySelector('.card_carousel'), {
        loop: true,
        pagination: {
          el: ".swiper-pagination",
          clickable: true,
        }
      });
    });
  }

  const productSizechart = (sizeChartContainer) => {
    if (sizeChartContainer.querySelector('#cm2') && sizeChartContainer.querySelector('#inches2') && sizeChartContainer.querySelector('table')) {

      function inchesToCentimeters(inches) {
        return inches * 2.54;
      }

      function centimetersToInches(cm) {
        return cm / 2.54;
      }

      function toggleUnit(unit) {
        let sizeCells = sizeChartContainer.querySelectorAll('td:not(.sc__item)');
        sizeCells.forEach(function(cell) {
          let originalValue = parseFloat(cell.getAttribute('data-original-value'));
          if (!isNaN(originalValue)) {
            if (unit === 'cm') {
              let cm = inchesToCentimeters(originalValue);
              cell.textContent = cm.toFixed(2);
            } else if (unit === 'inches') {
              let inches = originalValue;
              cell.textContent = inches.toFixed(2);
            }
          } else {
            cell.textContent = '-';
          }
        });

        if (unit === 'inches') {
          sizeChartContainer.querySelector('#inches2').classList.add('active');
          sizeChartContainer.querySelector('#cm2').classList.remove('active');
        } else if (unit === 'cm') {
          sizeChartContainer.querySelector('#cm2').classList.add('active');
          sizeChartContainer.querySelector('#inches2').classList.remove('active');
        }
      }

      function storeOriginalValues() {
        let sizeCells = sizeChartContainer.querySelectorAll('table td');
        sizeCells.forEach(function(cell) {
          let value = parseFloat(cell.textContent);
          if (!isNaN(value)) {
            cell.setAttribute('data-original-value', value);
          } else {
            cell.setAttribute('data-original-value', '-');
          }
        });
      }

      storeOriginalValues();

      let selectedUnit = 'inches';
      toggleUnit(selectedUnit);

      sizeChartContainer.querySelector('#cm2').addEventListener('click', function() {
        selectedUnit = 'cm';
        toggleUnit(selectedUnit);
      });

      sizeChartContainer.querySelector('#inches2').addEventListener('click', function() {
        selectedUnit = 'inches';
        toggleUnit(selectedUnit);
      });
    }
  }

  const sizeChartCloseBtn = (sizeChartContainer) => {
    sizeChartContainer.querySelector('.bt-sc-close-btn,.bt-sc-overlay').addEventListener('click', () => {
    //  if ( window.innerWidth > 768) {
        document.querySelector('.bt-sc-overlay').removeAttribute('style');
    //  }
      sizeChartContainer.removeAttribute('style');
      sizeChartContainer.querySelector('.bt-sc-items-container').innerHTML = null;
      sizeChartContainer.querySelector('img').src = '';
    });

    document.querySelector('.bt-sc-overlay').addEventListener('click', () => {
      document.querySelector('.bt-sc-overlay').removeAttribute('style');
      sizeChartContainer.removeAttribute('style');
      sizeChartContainer.querySelector('.bt-sc-items-container').innerHTML = null;
      sizeChartContainer.querySelector('img').src = '';
      document.querySelector('.bt-card-variant-list-wrapper').classList.remove('active');
    });
   
  }

  const sizeChartBtn = () => {
    document.querySelectorAll('.bt-qatc-measurement-input').forEach(scBtn => {
      scBtn.addEventListener('click', (evt) => {
        console.log('--?',evt.target.dataset)
        document.querySelector('#bt-sc-overlay').style.display = 'block';
        const sizeChartContainer = document.querySelector('#bt-sc-container');
        sizeChartContainer.style.transform = 'translateX(0px)';
        sizeChartContainer.querySelector('.bt-sc-title h2').innerText = evt.target.dataset.scTitle;
        sizeChartContainer.querySelector('.bt-sc-media img').src = evt.target.dataset.scImg;
        let cloneSc = evt.target.nextElementSibling.cloneNode(true);
        console.log('cloneSc',cloneSc)
        sizeChartContainer.querySelector('.bt-sc-items-container').append(cloneSc)
        sizeChartContainer.querySelector('.bt-sc-items-container .bt-qatc-collection-chart').style.display = 'block';

        sizeChartCloseBtn(sizeChartContainer);
        productSizechart(sizeChartContainer);
      });
    });
  }

  cardSlider();
  cardAtcBtn();
  variantListClose();
  sizeChartBtn();

  if (typeof Ajaxinate !== 'undefined' && gridWrapper) {
    const endlessScroll = new Ajaxinate({
      container: '#product-grid',
      pagination: '#AjaxinatePagination',
      loadingText: 'Loading...',
      method: "scroll",
      callback: function() {
        cardSlider();
        cardAtcBtn();
        variantListClose();
        sizeChartBtn();
      }
    });
  }

