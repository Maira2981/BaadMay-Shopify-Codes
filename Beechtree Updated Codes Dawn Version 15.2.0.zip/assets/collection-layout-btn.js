
const layoutToggleBtn = () => {
    const toggleBtn = document.querySelector('.toggle-layout-btn');
    const layout = document.querySelector('#product-grid');

    toggleBtn.addEventListener('click', () => {
      toggleBtn.classList.toggle('active');
      layout.classList.toggle('grid--4-col-desktop');
      layout.classList.toggle('grid--2-col-desktop');
    });

  };

  layoutToggleBtn();
