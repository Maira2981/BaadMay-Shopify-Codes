class CategorySwitcher extends HTMLElement {
  constructor() {
    super();
    this.querySelectorAll('[bt-category-switcher]').forEach( element => {
      element.addEventListener('click', this.onClick.bind(this));
    });
    this.fullPageSlider = document.querySelector('bt-fullpage-slider');
    this.categoryMenu = document.querySelectorAll('.bt__sidemenu_wrap .bt__sidemenu_parent');
    this.secondaryMenu = document.querySelectorAll('.bt__secondary_nav_wrp .bt__secondary_nav');
    this.onLoad('women');
  };
  
  onLoad(category) {
    /* Assuming the page name is derived from the URL */
    const currentPage = window.location.pathname;
    if (currentPage !== '/') {
      /* Adjust the condition based on your page naming convention */
      const defaultSwitcher = this.querySelector(`[data-filter-handle="${category}"]`);
      if (defaultSwitcher) {
        /* Trigger click event for the default category */
        defaultSwitcher.click();
      }
    }
  }

  onClick(event) {
    const currentValue = event.target.closest('button').getAttribute('data-filter-handle');
    this.fullPageSlider?.updateSlides(currentValue);
    document.querySelectorAll('[bt-category-switcher]').forEach(element => {
      const elementFilter = element.getAttribute('data-filter-handle');
      currentValue === elementFilter ? element.classList.add('active') : element.classList.remove('active');
    });

    this.categoryMenu.forEach( menuEl => {
      const menufilter = menuEl.getAttribute('data-menu');
      currentValue === menufilter ? menuEl.classList.add('active') : menuEl.classList.remove('active');
    });

    this.secondaryMenu.forEach(menuEl => {
      const menufilter = menuEl.getAttribute('data-menu');
      currentValue === menufilter ? menuEl.classList.add('active') : menuEl.classList.remove('active');
    });
  }
}

customElements.define('bt-category-switcher', CategorySwitcher);

class FullPageSlider extends CategorySwitcher {
  constructor() {
    super();
    this.sliderSettings = {
      direction: "vertical",
      speed: 700,
      mousewheel: true,
      updateOnWindowResize: true,
      slidesPerView: 1,
      slidesPerGroup: 1,
      mousewheel: {
        thresholdDelta: 80
      },
      pagination: {
        el: '.swiper-pagination',
        type: 'bullets',
        clickable: true
      },
      keyboard: {
        enabled: true,
        onlyInViewport: false,
      },
      effect: "creative",
      creativeEffect: {
        prev: {
          translate: [0, "-0%", -1],
        },
        next: {
          translate: [0, "100%", 0],
        },
      },
    }
    this.initSlider();
    this.activeWomenSlides();
    this.categorySlides = this.querySelectorAll('[data-slide-filter="women"], [data-slide-filter="kids"]');
  }

  autoPlayVideosOnLoad() {
    const allVideos = document.querySelectorAll('.bt__fullpage_inner video');
    allVideos.forEach( video => {
      video.play();
    });
  }

  initSlider() {
    this.swiperEl = new Swiper(this, this.sliderSettings);
    const activeSlide = this.querySelector('.slide-visible');
    const slideColor = activeSlide.getAttribute('data-slide-color');
    document.documentElement.style.setProperty('--color-header', slideColor);
    this.swiperEl.on("slideChangeTransitionEnd", this.changeSlide.bind(this));
    this.autoPlayVideosOnLoad();
  }

  activeWomenSlides() {
    setTimeout(() => {
      document.querySelector('[data-filter-handle="women"]').click();
    }, 1000);
  }

  destroySlider() {
    if (this.swiperEl) {
      this.swiperEl.destroy();
    }
  }

  updateSlider() {
    if (this.swiperEl) {
      this.swiperEl.update();
    }
  }

  disableSlider() {
    if (this.swiperEl) {
      this.swiperEl.disable();
    }
  }

  changeSlide(event) {
    const activeSlide = event.el.querySelector('.swiper-slide-visible');
    const slideColor = activeSlide.getAttribute('data-slide-color');
    document.documentElement.style.setProperty('--color-header', slideColor);
    if (this.swiperEl.isEnd) {
      document.querySelector('body').classList.add('active-footer');
    } else {
      document.querySelector('body').classList.remove('active-footer');
    }
  }

  prependChild(newElement) {
    if (this.firstChild) {
      return this.insertBefore(newElement, this.firstChild);
    } else {
      return this.appendChild(newElement);
    }
  }

  updateSlides(filter) {
    const sliderInnerWrapper = this.querySelector('.swiper-wrapper');
    const categorySlides = this.querySelectorAll('[data-slide-filter="women"], [data-slide-filter="kids"]');
    const filteredSlides = Array.from(this.categorySlides).filter( el => {
    const elAttr = el.getAttribute('data-slide-filter');
      if (elAttr === filter) {
        return el;
      }
    });
    this.destroySlider();
    categorySlides.forEach(removeEl => {
      removeEl.remove();
    });
    sliderInnerWrapper.prepend(...filteredSlides);
    setTimeout(() => {
      this.initSlider();
    }, 500);
  }
}

customElements.define('bt-fullpage-slider', FullPageSlider);

var ulElements = document.querySelectorAll('ul.tag_links');
ulElements.forEach( ul => {
  if (!ul.querySelector('li')) {
    ul.classList.add('empty');
  }
});
